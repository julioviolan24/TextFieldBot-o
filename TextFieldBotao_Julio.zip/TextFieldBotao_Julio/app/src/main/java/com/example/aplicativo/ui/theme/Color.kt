package com.example.aplicativo.ui.theme

import androidx.compose.ui.graphics.Color

val Orange = Color(0xFFFFA500)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Yellow = Color(0xFFFFFF00)

val val Orange = Color(0xFFFFA500)
val PurpleGrey40 = Color(0xFF625b71)
val Yellow = Color(0xFFFFFF00)

val DarkGreen = Color (0xFF388E3C)
val Yellow = Color(0xFFFFFF00)
val DarkOrange = Color(0xFFFF6F00)
val DarkRed = Color( 0xFFB71C1C)